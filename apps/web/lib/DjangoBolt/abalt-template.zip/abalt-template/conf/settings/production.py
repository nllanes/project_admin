"""Production settings and globals."""

from base import *
